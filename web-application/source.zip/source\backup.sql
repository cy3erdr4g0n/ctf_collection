create database demo;
use demo;
CREATE USER 'hacker'@'localhost' IDENTIFIED BY 'password';
GRANT ALL PRIVILEGES ON demo.* TO 'hacker'@'localhost';
FLUSH PRIVILEGES;

DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(32) DEFAULT NULL,
  `body` text,
  `author_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
); 
INSERT INTO `posts` VALUES (1,'ABCCTF 2023','Built into this year’s Cybersecurity Project is yet another exciting cybersecurity Hackathon. The American Business Council Nigeria (ABC Nigeria) & Comercio in partnership with Private Sector partners are hosting a Cyber Hackathon 2023. The Council wishes to draw attention to the talents that exist in this space whilst highlighting the need to help build capacity and innovation that not only strengthen and sustain Africa’s cybersecurity ecosystem but allows for competition on a global level. It is the desire of ABC and its partners to have the hackathon that will encourage discussions about innovation, upskilling, entrepreneurship and mentorship in Africa’s cyberspace, cyber-attacks and how to mitigate them, and the state of the continent’s cybersecurity regulatory framework. This initiative seeks to drive capital, capacity and policy investment required to effectively secure Africa’s digital space.',1);

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(128) DEFAULT NULL,
  `password` varchar(128) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
);

INSERT INTO `users` VALUES (1,'rudefish','$2b$12$poLViz9Y.eqTySckpeukI.k3ASSJ/OG3k/YklyFLbGxE43H4DD/h6','rudefish@ctf.ng');
INSERT INTO `users` VALUES (2,'flag','dummy_flag','flag@ctf.ng');